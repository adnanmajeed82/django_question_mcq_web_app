from django.contrib import admin
from mysite.models import Question, Choice

admin.site.register(Question)
admin.site.register(Choice)
